# 🩸 LifePulse - Smart Blood Donor Network

> **A modern, responsive, and advanced blood donor management and emergency blood matching portal.**  
> LifePulse connects blood donors directly with patients and hospitals in critical emergencies, providing real-time blood group availability tracking, smart compatibility matching, one-click WhatsApp & phone coordination, and secure user authentication.

---

## 🌟 Key Features & Advanced Capabilities

### 1. 📊 Interactive Analytics & Dashboard
- **Live Metrics**: Total registered donors, ready/available donors, active emergency requests, and coverage across cities.
- **Real-Time Blood Type Inventory**: Instant cards for all 8 blood groups (`A+`, `A-`, `B+`, `B-`, `AB+`, `AB-`, `O+`, `O-`) with one-click filtering.
- **Interactive Visual Distribution**: Embedded interactive donut chart powered by Chart.js.
- **Urgent Need Broadcasts**: Live feed of active emergency requests prioritized by urgency (`Critical`, `Urgent`, `Standard`).

### 2. 👥 Smart Donors Directory & Live Multi-Filter
- **Multi-Parameter Search & Filter**:
  - Filter by Blood Group.
  - Filter by City (dynamically extracted from the database).
  - Filter by Availability Status (`Available`, `Donated Recently (< 90 days)`, `Unavailable`).
  - Text search by Donor Name, Phone Number, or City.
- **Direct Lifesaving Actions**:
  - 💬 **One-Click WhatsApp Integration**: Pre-populates an urgent emergency request message directly addressed to the donor.
  - 📞 **Instant Call**: Directly initiates phone call via `tel:` protocol.
  - 📋 **Copy to Clipboard**: Fast phone copy with animated toast notification.
  - ✏️ **Edit & Manage**: Update donor contact details, availability, and donation records.
  - 🗑️ **Safe Deletion**: Integrated deletion modal with confirmation.

### 3. 🚨 Emergency & Urgent Blood Requests Portal
- Broadcast urgent blood requirements for patients and hospitals:
  - Patient Name, Required Blood Group, Units Needed.
  - Hospital Name, City, and Coordinator Phone Number.
  - Urgency Level: **Critical** (Immediate / < 2 Hours), **Urgent** (< 24 Hours), **Standard**.
  - Notes for surgery type or special requirements (e.g., platelet donation).
- **One-Click Donor Matcher**: From any blood request, click **"Match Donors"** to instantly query compatible donors for that patient's blood group.
- Status toggle: Mark requests as **Fulfilled** once blood is arranged, or reopen if needed.

### 4. 🧬 Medically Validated Blood Compatibility Matrix & Smart Matcher
- Interactive tool allowing users to pick any of the 8 blood groups to instantly display:
  - Which blood types they can safely receive red blood cells from.
  - Which blood types they can safely donate red blood cells to.
  - Universal Donor (`O-`) and Universal Recipient (`AB+`) medical alerts.
  - Direct listing of all available donors in the network compatible with the selected recipient!

### 5. 📥 One-Click CSV Export
- Download the complete directory of blood donors as a formatted `.csv` spreadsheet file with a single click (`/export_csv`) for offline hospital coordination and emergency logs.

### 6. 🔒 Enterprise-Grade Security & Authentication
- **Secure Password Hashing**: Utilizes Werkzeug's cryptographic hashing (`scrypt` / `pbkdf2`) with automatic legacy plain-text password upgrading.
- **Real-Time Password Complexity Meter**: Live interactive checklist validating 8+ characters, uppercase letter, number, and special character during registration.
- **Two-Factor / Password Reset OTP**: 6-digit OTP email verification via SMTP with automated fallback for offline/demo environments.
- **Show/Hide Password Visibility Toggle** on all authentication forms.

---

## 🛠️ Technology Stack

- **Backend**: Python 3.x, Flask, Werkzeug Security, SQLite3
- **Frontend**: HTML5, Modern Responsive CSS3 (Design Tokens, Glassmorphism, Micro-animations)
- **Typography & Icons**: Google Fonts (*Plus Jakarta Sans* & *Outfit*), Font Awesome 6.5
- **Charts & Visualizations**: Chart.js
- **Database**: SQLite (`donors.db`) with automatic schema migration

---

## 🚀 Quick Start Guide

### 1. Requirements
Ensure Python 3.10+ is installed on your machine.

### 2. Install Dependencies
```bash
pip install flask
```

### 3. Run the Application
```bash
python app.py
```

Open your browser and navigate to:
```
http://127.0.0.1:5000
```

### 4. Default Login Credentials
You can sign in using your existing account or create a new one via `/register`:
- **Email**: `sagargpprince@gmail.com`
- Or use any newly registered account with a strong password.

---

## 📁 Project Structure

```
Blood_donar/
├── app.py                  # Core Flask backend, routes, database & auth logic
├── donors.db               # SQLite database with donors, users, and blood requests
├── README.md               # Project documentation
├── test_routes.py          # Integration test suite for all routes
├── test_actions.py         # Functional test suite for donor & request actions
├── static/
│   ├── style.css           # Modern design system, utility classes, and components
│   ├── blood_bg.jpg        # Background asset
│   ├── login_bg.jpg        # Background asset
│   └── forgot_bg.jpg       # Background asset
└── templates/
    ├── base.html           # Master responsive layout, navigation, flash alerts & toasts
    ├── dashboard.html      # Analytics dashboard with metrics, inventory & Chart.js
    ├── view.html           # Donors directory with multi-filter, search & contact actions
    ├── index.html          # Add donor registration with medical eligibility checklist
    ├── edit_donor.html     # Edit donor profile and donation history
    ├── requests.html       # Emergency blood requests board with urgency badges
    ├── compatibility.html  # Interactive compatibility matcher & compatible donors list
    ├── login.html          # Modern login with password toggle
    ├── register.html       # Register page with live interactive password strength meter
    ├── forgot.html         # Password recovery with OTP request
    ├── otp.html            # 6-digit OTP verification screen
    └── reset.html          # Password reset with confirmation check
```

---

## 🩸 Blood Group Compatibility Reference

| Blood Group | Can Safely Donate To | Can Safely Receive From |
|:-----------:|:---------------------|:------------------------|
| **O-**      | **Everyone** (Universal Donor) | O- |
| **O+**      | O+, A+, B+, AB+ | O+, O- |
| **A-**      | A-, A+, AB-, AB+ | A-, O- |
| **A+**      | A+, AB+ | A+, A-, O+, O- |
| **B-**      | B-, B+, AB-, AB+ | B-, O- |
| **B+**      | B+, AB+ | B+, B-, O+, O- |
| **AB-**     | AB-, AB+ | AB-, A-, B-, O- |
| **AB+**     | AB+ | **Everyone** (Universal Recipient) |

---

## 🛡️ License
Designed and maintained for community healthcare, NGOs, hospitals, and emergency blood coordination networks.
